﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightning : MonoBehaviour {

    Vector2 startpos;

	// Use this for initialization
	void Start () {

        startpos = transform.position;

	}
	
	// Update is called once per frame
	void Update () {

        if (transform.position.y <= (startpos.y + .5f))
        {
        }
	}
}
