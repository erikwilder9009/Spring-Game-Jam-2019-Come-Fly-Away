﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class balloonmove : MonoBehaviour {

    Rigidbody2D rb;
    
    public GameObject basket;
    public GameObject popped;

    public bool alive;

    public int hp;

    bool hit;

	// Use this for initialization
	void Start () {
        rb = gameObject.GetComponent<Rigidbody2D>();
        hp = 10;
        hit = false;

    }
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey(KeyCode.Space) && alive)
        {
            rb.AddForce(transform.up * 1.5f);

            //Debug.Log("Up");
        }

        if (Input.GetKey(KeyCode.C) && alive)
        {
            rb.AddForce(transform.up * -1);

            //Debug.Log("Down");
        }

        if (Input.GetKeyDown(KeyCode.X) && alive)
        {
            rb.velocity= (Vector3.zero);

            //Debug.Log("Down");
        }

        if (hp == 0||transform.position.x < -12)
        {
            alive = false;
        }
        if(!alive)
        {
            fall();
        }

    }
    

    private void OnTriggerEnter2D(Collider2D other)
    {
        wind bm = other.GetComponent<wind>();
        rock rck = other.GetComponent<rock>();
        lightning light = other.GetComponent<lightning>();
        bounds edge = other.GetComponent<bounds>();

        if (!hit)
        {
            if (bm)
            {
                if (bm.upwind)
                {
                    rb.AddForce(-transform.up * -200);
                }
                else
                {
                    rb.AddForce(-transform.up * 200);
                }
            }
            if (rck)
            {
                hp -= 1;
                Debug.Log("Hit rock");
            }

            if (light)
            {
                alive = false;
                Debug.Log("Hit lightning");
            }

            if (edge)
            {
                alive = false;
                Debug.Log("over edge");
            }
        }
        
    }


        public void fall()
    {


        background.instance.paused = true;
        Instantiate(popped, transform.position, transform.rotation);
        Instantiate(basket, transform.position, transform.rotation);
        Destroy(gameObject);

        SceneManager.LoadScene("main menue");
    }

    void Reset()
    {

    }
}
