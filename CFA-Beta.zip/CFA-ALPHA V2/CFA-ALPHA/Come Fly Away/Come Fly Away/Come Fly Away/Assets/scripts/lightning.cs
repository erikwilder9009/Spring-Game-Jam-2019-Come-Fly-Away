﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightning : MonoBehaviour {

    public Vector2 startpos;

    //bool movedown;

    bool bigger;

	// Use this for initialization
	void Start () {

        //startpos = gameObject.transform.position;
        //movedown = true;
        bigger = true;
	}
	
	// Update is called once per frame
	void Update () {

        Debug.Log(transform.localScale);

        if(transform.localScale.y >= 7)
        {
            bigger = false;
        }
        if(transform.localScale.y <= 2)
        {
            bigger = true;
        }

        if(bigger)
        {
            transform.localScale += (transform.up * .5f);
        }
        else
        {
            transform.localScale -= (transform.up * .5f);
        }










        //if (transform.position.y == startpos.y - 25)
        //{
        //    movedown = false;
        //    Debug.Log(transform.position);
        //}
        //if (transform.position.y == startpos.y)
        //{
        //    movedown = true;
        //}
        //
        //if (movedown)
        //{
        //    transform.Translate(-transform.up * .5f);
        //}
        //else
        //{
        //    transform.Translate(transform.up * .5f);
        //}
	}
}
