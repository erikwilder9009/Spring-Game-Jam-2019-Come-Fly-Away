﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class background : MonoBehaviour {

    public static background instance;

    public bool paused;
    public float movespeed;

	// Use this for initialization
	void Start () {
        instance = this;
        movespeed = .05f;
	}

    // Update is called once per frame
    void Update() {

        if (!paused)
        {
            gameObject.transform.Translate(-transform.right * movespeed);
        }
	}
}
