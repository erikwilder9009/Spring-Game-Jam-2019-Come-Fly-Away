﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class balloonmove : MonoBehaviour {
    

    Rigidbody2D rb;
    public GameObject basket;
    public GameObject popped;

    public int hp;
    public float pressure;
    public int water;
    
    public bool alive;
    bool hit;
    
    public GameObject needlespinner;
    public GameObject Waterneedlespinner;

	// Use this for initialization
	void Start () {
        rb = gameObject.GetComponent<Rigidbody2D>();
        hp = 6;
        hit = false;

        pressure = 25;
        needlespinner.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 50));
        water = 0;
        Waterneedlespinner.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 37));
    }
	
	// Update is called once per frame
	void Update () {
        
        //Needle Controll
        needlespinner.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 50 - (1.2f * pressure)));
        Waterneedlespinner.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 50 - (33.6f * water)));

        //Fly Up
        if (Input.GetKey(KeyCode.Space) && alive)
        {
            rb.AddForce(transform.up * 1.5f);

            pressure += .5f;
            Debug.Log(pressure);
            //If pressure is higher than 100
            if(pressure >= 100)
            {
                Debug.Log("High Pressure");
                alive = false;
            }
        }

        //Vent
        if (Input.GetKey(KeyCode.C) && alive && pressure >= 0)
        {
            rb.AddForce(transform.up * -1);

            pressure -= 2f;
            Debug.Log(pressure);
        }

        //Air brake
        if (Input.GetKeyDown(KeyCode.X) && alive && pressure >= 25)
        {
            rb.velocity= (Vector3.zero);

            pressure -= 25f;
            Debug.Log(pressure);
        }

        if (hp == 0||transform.position.x < -12)
        {
            alive = false;
        }
        if(pressure <= 0)
        {
            rb.AddForce(transform.up * -3);
        }
        if(water > 5)
        {
            alive = false;
        }

        //If you die
        if (!alive)
        {
            fall();
        }
    }
    

    private void OnTriggerEnter2D(Collider2D other)
    {
        wind bm = other.GetComponent<wind>();
        rock rck = other.GetComponent<rock>();
        lightning light = other.GetComponent<lightning>();
        bounds edge = other.GetComponent<bounds>();
        goal win = other.GetComponent<goal>();
        boss biggy = other.GetComponent<boss>();

        if (!hit)
        {
            //Wind
            if (bm)
            {
                if (bm.upwind)
                {
                    rb.AddForce(transform.up * 200);
                }
                else
                {
                    rb.AddForce(-transform.up * 200);
                }
            }

            //Rock
            if (rck)
            {
                hp -= 1;
                Debug.Log("Hit rock");
            }

            //Lightning
            if (light)
            {
                alive = false;
                Debug.Log("Hit lightning");
            }

            //Over Edge
            if (edge)
            {
                alive = false;
                Debug.Log("over edge");
            }

            //Boss
            if(biggy)
            {
                rb.AddForce(-transform.right * 200);
            }
        }

        //GOOOOOOAL
        if(win)
        {
            SceneManager.LoadScene("winning");
        }
        
    }


    //THIS IS WHAT HAPPENS WHEN YOU DIE!!!!!!!
        public void fall()
    {


        background.instance.paused = true;
        Instantiate(popped, transform.position, transform.rotation);
        Instantiate(basket, transform.position, transform.rotation);
        Destroy(gameObject);

        SceneManager.LoadScene("main menue");
    }
}
