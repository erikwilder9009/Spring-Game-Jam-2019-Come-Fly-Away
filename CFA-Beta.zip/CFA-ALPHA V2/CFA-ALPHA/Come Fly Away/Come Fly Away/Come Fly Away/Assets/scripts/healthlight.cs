﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class healthlight : MonoBehaviour {

    public balloonmove bm;

    public int hp;

    public GameObject off;
    public GameObject on;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
        if(bm.hp < hp)
        {
            off.SetActive(true);
            on.SetActive(false);
        }
        else
        {
            on.SetActive(true);
            off.SetActive(false);
        }

	}
}
