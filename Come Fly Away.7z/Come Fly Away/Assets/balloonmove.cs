﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class balloonmove : MonoBehaviour {

    Rigidbody2D rb;
    
    public GameObject basket;

    public bool alive;

	// Use this for initialization
	void Start () {
        rb = gameObject.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey(KeyCode.Space) && alive)
        {
            rb.AddForce(transform.up * 1.5f);

            //Debug.Log("Up");
        }

        if (Input.GetKey(KeyCode.C) && alive)
        {
            rb.AddForce(transform.up * -1);

            //Debug.Log("Down");
        }

        if (Input.GetKeyDown(KeyCode.X) && alive)
        {
            rb.velocity = (Vector3.zero);
        }
        

        if(!alive)
        {
            fall();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        wind bm = other.GetComponent<wind>();
        if(bm.upwind)
        {
            rb.AddForce(-transform.up * -200);
        }
        else
        {
            rb.AddForce(-transform.up * 200);
        }

        Debug.Log("Hit");
    }


    public void fall()
    {
        Instantiate(basket);
        Destroy(gameObject);
    }
}
